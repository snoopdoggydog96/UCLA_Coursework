#include <unistd.h>
#include <stdio.h>
#include <getopt.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <poll.h>
#include <time.h>
#include <math.h>
#include "fcntl.h"
#include <stdlib.h>
#include <ctype.h>
#include <mraa.h>
#include <aio.h>
#include <mraa/aio.h> //this is included in the beaglebone

//GLOBALS
const int B = 4275;               // B value of the thermistor
const int R0 = 100000;            // R0 = 100k

int period = 1;
char default_temp = 'f';
char * logFile;
int is_log = 0;
FILE * logPtr = NULL;
int logfd;
int stop = 0;
int off = 0;

void
user_error(void)
{
  fprintf(stdout, "User entered command other then START=f, START=c, OFF, or is_log=*log_file_name*. Exiting_Immediately.\n"); 
  exit(1); 
}

double
convert(int analogSig, char f_c)
{
    double R = 1023.0/(double)(analogSig)-1.0;
    R = R0*R;
    double conversion = 1.0/(log((R/R0))/B + 1 / 298.15) - 273.15; // convert to temperature via datasheet
    return f_c == 'C'? conversion : conversion * 9/5 + 32;
}

void
input_commands(int argc, char ** argv)
{
    static struct option long_options[] = {
        {"period", required_argument, 0, 'p'},
        {"scale", required_argument, 0, 's'},
        {"log", required_argument, 0,'l'},
        {0,         0,                 0,  0 }
    };
    int c;
    while (1)
      {
        c = getopt_long(argc, argv, "", long_options, 0);
        if (c == -1)
	  break;
	switch (c)
	  {
	  case 'p'://set the shellflag
	    period = atoi(optarg);
	    break;
	  case 's':
	    if (optarg[0] == 'c' || optarg[0] == 'C')
	      default_temp = 'C';
	    else if (optarg[0] == 'f' || optarg[0] == 'F')
	      default_temp = 'F';
	    else
	      {
		fprintf(stderr, "Must enter F, f, C or c for correct units. Exiting Immediately.\n"); 
		exit(1);
	      }
	    break;
	  case 'l':
	    is_log = 1;
	    logFile = optarg;
	    logPtr = fopen(logFile, "w");
	    if (logPtr == NULL)
	      {
		perror("Not able to open log file. Exiting immediately. \n"); 
		exit(2);
	      }
	    break;
	  case '?':
	  default:
	    //this means that the user input unrecognized argument to the program
	    user_error(); 
	    break;
	  }         
      }
}

void
change_scale(char unit)
{
  if ((unit == 'C') || (unit == 'c'))
    {
      default_temp = 'C';
      fprintf(stdout, "SCALE=C\n");
      if (is_log && stop == 0)
	fprintf(logPtr, "SCALE=C\n");
    }
  else if ((unit == 'F') || (unit == 'f'))
    {
      default_temp = 'F';
      fprintf(stdout, "SCALE=F\n)");
      if (is_log && stop == 0)
	fprintf(logPtr, "SCALE=F\n");
    }
  else
    fprintf(stderr, "Error changing from C to F or F to C. Exiting Immediately.\n"); 
}
void
change_period (int given)
{
  period = given;
  fprintf(stdout, "PERIOD=%d\n", given); 
  if (is_log && stop == 0)
    fprintf(logPtr, "PERIOD=%d\n", given);
}

#define START 1
#define STOP 0
void
stop_start(int flag)
{
  if (flag == START)
    {
      stop = 0; 
      fprintf(stdout, "START\n");
      if (is_log)
	fprintf(logPtr, "START\n");
    }
  else
    {
      stop = 1; //stop
      fprintf(stdout, "STOP\n");
      if (is_log)
	fprintf(logPtr, "STOP\n");
    }
}

void
bbgw_log(char *str, int num_chars)
{
  char log_string[num_chars];
  int i;
  for ( i = 0; i < num_chars; i++)
    log_string[i] = str[i]; 
  
  if (is_log)
    fprintf(logPtr, "LOG %s\n", log_string); 
  
  fprintf(stdout, "LOG %s\n", log_string); 
}

void
shutdown()
{
  time_t raw; 
  struct tm *get_time; 
  time(&raw); 
  get_time = localtime(&raw); 
  fprintf(stdout, "OFF\n");
  //fprintf(stdout, "%d:%d:%d SHUTDOWN\n",get_time -> tm_hour, get_time ->tm_min, get_time ->tm_sec);
  fprintf(stdout, "%.2d:%.2d:%.2d SHUTDOWN\n",get_time->tm_hour, get_time->tm_min, get_time->tm_sec);
  
  if (is_log)
    {
      fprintf(logPtr, "OFF\n");
      fprintf(logPtr, "%.2d:%.2d:%.2d SHUTDOWN\n",get_time->tm_hour, get_time->tm_min, get_time->tm_sec);
    }
  exit(0);
}



void
command(char * str)
{ //assume that str is null terminated
    //    fprintf(stderr, "Received str: %s\n", str);
    if (str == NULL)
      {
      fprintf(stderr, "Error, null char detected. Exiting Immediately.\n");
      exit(2);
      }
    //check if the command is \n new-line terminated
    //check the strings
    int is_log= 1;
    int period = 1;
    if (strcmp(str, "OFF") == 0) shutdown();
    if (strcmp(str, "SCALE=F") != 0) change_scale('F');
    else if (strcmp(str, "SCALE=c") != 0 ) change_scale('C');
    if (strcmp(str, "SCALE=F") != 0) change_scale('F');
    else if (strcmp(str, "SCALE=C") != 0 ) change_scale('C');
    //start and stop
    else if (strcmp(str, "STOP") == 0) stop_start(STOP);
    else if (strcmp(str, "START") == 0) stop_start(START);
    else
      {
        //now log, or priod, or bogus
	char *log_str= "LOG ";
        if (strlen(str) <= strlen(log_str))
	  {
            user_error();
            return;
	  }
        int i ;
        for (i = 0; i < 4 && is_log == 1; i++)
	  {
            if (str[i] != log_str[i])
	      {
                is_log = 0;
                break;
	      }
	  }
        if (is_log)
	  {
	    int  count = 0; 
	    char logStr[40];
            //read characters until the null char and size of the string
            unsigned int j = 0;
            while ((str[j+4] != '\0' && str[j+4] != '\n') && j + 4 < strlen(str))
	      {
                logStr [j] = str[j+4];
                count++; 
                j++;
            }
            bbgw_log(logStr, count); 
            return;
        }
        //now check if it is a period
        char * period_str="PERIOD=";
        if (strlen(str) <= strlen(period_str))
	  {
            period = 0;
            user_error();
	  }
        //now make sure that it has the same spelling as PERIOD
        int j = 0;
        for (; j < 7; j++)
	  {
            if (period_str[j] != str[j])
	      user_error();
	  }
        //now keep we have to read the value of the PERIOD
        //j == 7 now
        int period_count = 0;
        //can read just one digit value
        while (str[j] != '\n')
	  {
            //read character by char to make sure we have digits
            if (!isdigit(str[j]))
	      user_error();
            j++;
            period_count++;
	  }
        char buff[period_count];
        int k;
        for (k = 7; k < period_count + 7; k++) //7 because is the index right after =, PERIOD=
	  buff[k-7]= str[k];
        
        change_period(atoi(buff));
	
        if ((!is_log) && (!period))
	  user_error();
      }
}

void
buttonPressed()
{  
}

int
main(int argc, char ** argv) {
    
    input_commands(argc, argv); //to set the flags and initialize as we want
    //now setup the temp. sensor and the button
    mraa_gpio_context button;
    button = mraa_gpio_init (62); //acctually connected to GPIO = 51 ==> maps to ==> 62
    mraa_gpio_dir(button,MRAA_GPIO_IN);
    //but GPIO pin read is a non-blocking operation, so you can simply read the button status once per second.
    ////IMPORTANT,so read the value of GPIO instead of interupting
    
    //mraa_gpio_isr(button,MRAA_GPIO_EDGE_RISING, &buttonPressed, NULL);
    
    //also setup the temperature sensor
    int sensor; 
    mraa_aio_context temp_sensor;
    temp_sensor = mraa_aio_init(1);
    
    //setting up polling
    struct pollfd pollfds [1];
    pollfds[0].fd= STDIN_FILENO;
    pollfds[0].events = POLLIN | POLLHUP | POLLERR; //waiting for this event to occur
    while (1)
      {//read the values and output the values that are read
        sensor = mraa_aio_read(temp_sensor);
        double temp = convert(sensor, default_temp);
        time_t raw;
        struct tm *get_time;
        time (&raw);
        get_time = localtime(&raw); 
        if (stop == 0)
	  fprintf(stdout, "%.2d:%.2d:%.2d %.1f\n",get_time -> tm_hour, get_time ->tm_min, get_time ->tm_sec, temp);
	if (is_log)
	  fprintf(logPtr, "%.2d:%.2d:%.2d %.1f\n",get_time -> tm_hour, get_time ->tm_min, get_time ->tm_sec, temp);
        
	//usleep(period * 1000000);//since the number used is in microseconds
	time_t begin, end;
	time(&begin);
	time(&end);
	while (difftime(end, begin) < (period))
	  {
	    if (mraa_gpio_read (button))
	      shutdown();
	    int polled = poll(pollfds, 1, 0);
	    if (polled == -1)
	      {
		fprintf(stderr, "Error with poll. Exiting Immediately.\n"); 
		exit(1);
	      }
	    if (pollfds[0].revents & POLLIN)
	      {
		//my main problem is to make sure that make sure that the string is null terminated
		//get the string
		//compare with possible values
		//check if it is null terminated ==> if not return immediately
		char tempBuff[35]; 
		memset(tempBuff, 0, 35*sizeof(char));//zero them out
		//scanf("%s",tempBuff);
		//fgets(<#char *restrict#>, <#int#>, <#FILE *#>)
                fgets(tempBuff, 35, stdin);
                command(tempBuff);
	      }
	    time(&end);
	  }
      }
    //dont forget to close the the sensors,
    close (logfd);
    exit(0); 
}

