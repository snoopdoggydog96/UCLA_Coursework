/*NAME: Anup Kar
EMAIL: akar@g.ucla.edu
UID: 204419149
*/
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <termios.h>
#include <string.h>
#include <getopt.h>
#include <pthread.h>
#include <sys/types.h>
#include <signal.h>
#include <poll.h> /*for poll(), pollfd struct, for interprocess communication*/ 
#include <errno.h>
#include <sys/wait.h> /* for waitpid() and equivalent WEXITSTATUS, WTERMSIG macros for wait on child process return*/

/* error handler functions after we have detected a system call has returned incorrectly in our main program */
void
pipe_error(int i_o)
{
  switch (i_o)
    {
    case 1:
      fprintf(stderr, "pipe() failed piping STDOUT. Exit. \n");
      exit(1);
    case 0:
      fprintf(stderr, "pipe() failed piping STDIN. Exit. \n");
      exit(1);
    default:
      fprintf(stderr, "pipe() failed. Exit. \n");
      exit(1);
    }
}

void
exec_error(void)
{
  fprintf(stderr, "exe() failed. Exit.\n");
  exit(1); 
}

void
dup2_error(int i_o)
{
  switch (i_o)
    {
    case 1:
      fprintf(stderr, "dup2() failed copying STDOUT to pipe. Exit. \n");
      exit(1);
    case 0:
      fprintf(stderr, "dup2() failed copying STDIN to pipe. Exit. \n");
      exit(1);
    case 2:
      fprintf(stderr, "dup2() failed copying STDERR to pipe. Exit. \n");
      exit(1); 
    default:
      fprintf(stderr, "dup2() failed. Exit. \n");
      exit(1);
    }
}

void
exit_msg(void)
{
  fprintf(stderr, "EXIT SUCCESS!\n");
  exit(0); 
}
void
write_error(void)
{
  fprintf(stderr, "Broken Pipe. Exit. \n");
  exit(1);
}
void
read_fail(void)
{
  fprintf(stderr,"Not able to read from stdin. Reason: %s \n", strerror(errno));
  exit(1); 
}

void 
close_error(void)
{
  fprintf(stderr, "Error closing specified FD. Reason: %s \n", strerror(errno)); 
  exit(1); 
}
void
poll_error(void)
{
  fprintf(stderr, "Error polling array of Open File Descriptors. Reason: %s \n", strerror(errno));
  exit(1); 
}
void 
wait_error(void)
{
  fprintf(stderr, "Child process failed returning. Exiting immediately. \n\r");
  exit(1); 
}

/*sighandler for SIGPIPE in case process attempts to write to a closed pipe*/
void
sigHandler_sigPipe(int sigNum)
{
  fprintf(stderr, "Called Signal Handler but have not yet received any input. Exit with Sig Num: %d \n", sigNum);
  exit(1); 
}

/* function to see if ^C was input by user in any of the char buffs[] from our read */
int
ctrl_c(char *buff, int rc)
{
  if (buff == NULL || rc <= 0) return 0; 
  else
    {
      char *ctrl_c = buff; 
      while (rc > 0)
	{
	  if (*(ctrl_c) == 3) return 1; 
	  else
	    ctrl_c++; 
	  rc --;
	}
    }
  return 0; 
}

/* function to see if ^D was input by user in any of the char buffs[] from our read */
int
ctrl_d(char *buff, int rc)
{
  if (buff == NULL || rc <= 0) return 0; 
  else
    {
      char *ctrl_d = buff; 
      while (rc > 0)
	{
	  if (*(ctrl_d) == 4) return 1; 
	  else
	    ctrl_d++;
	  rc--;
	}
    }
  return 0; 
}

int main(int argc, char **argv)
{
  char c;
  int shell = 0;
  
  signal(SIGPIPE, sigHandler_sigPipe);
  /*using getopt_long to parse commond line options and check for --bogus args */
     static struct option long_options[] =
       {
	 {"shell", no_argument, 0,'s'},
	 {0, 0, 0, 0}
       };
     while (1)
       {
	 c = getopt_long(argc, argv, "", long_options, 0);
	 if (c==-1) break;
	 switch(c)
	   {
	     
	   case 's':
	     shell=1;
	     break;
	   default:
	     fprintf(stderr,"Usage: ./lab1a, with optional flags --shell. \n");
	     exit(1);
	     break;
	   }
       }
     /*2 pipes for bidirectional I/O  from parent process to child, or from child to parent */
     int to_child[2];
     int from_child[2];
     
     if (pipe(to_child) == -1) pipe_error(1); /*check bad pipe() sys call*/
     if (pipe(from_child) == -1) pipe_error(0); /* check bad pipe() sys call */ 
     
     char buff[127]; /*store intial reads in buff*/ 
     
     /*2 termios variables, one to hold old terminal settings, one to set new terminal settings*/
     struct termios old, new;

     /*get old terminal settings, edit them to make them non-canonical input mode with no echo */
     tcgetattr(STDIN_FILENO, &old); 
     /*copy old to new - allows easily restoring terminal attributes upon exit */  
     new = old;  
     
     /* FROM SPEC :enables no-echo, character-at-a-time, for terminal attributes */
     /* e.g. NON-CANONICAL INPUT MODE WITH NO ECHO */
     new.c_iflag = ISTRIP;/* only lower 7 bits */ 
     new.c_oflag = 0;/*no processing*/
     new.c_lflag = 0;/*no processing*/
     
     new.c_cc[VTIME] = 0; /*no waiting*/
     new.c_cc[VMIN] = 1; /*1 char at a time*/
     
     /*set terminal attributes of STDIN_FILENO NOW (TCSANOW), to non-canonical input mode with no echo (&new) */
     tcsetattr(STDIN_FILENO, TCSANOW, &new);
     
     /*if shell flag is invoked we must fork() to create a new process, this means child process gets all code that goes before this */
     if (shell == 1)
       {
	 /* fork returns 0 for child process i.e. succesful creation of child process, nonzero for parent process (returns Childs ID) */  
	 int child = fork();
	 /* checking return value of fork() to process identify whether it is parent or child */ 
	 if (child == 0) /*CHILD PROCESS */
	   {
	     /*child process does not need to check for bad close() because this is first time process calls close on these FILE DESCRIPTORS present in both parent process and child process. */
	     close(to_child[1]);
	     close(STDIN_FILENO); 
	     if(dup2(to_child[0], STDIN_FILENO) == -1) dup2_error(0); /*check bad dup2() sys call attempting to copy STDIN_FILENO to to_child[0]*/

	     close(from_child[0]);
	     close(STDOUT_FILENO); 
	     if(dup2(from_child[1], STDOUT_FILENO) == -1) dup2_error(1); /*check bad dup2() sys call attempting to copy STDOUT_FILENO to from_child[1] */
	     
	     close(STDERR_FILENO);
	     if(dup2(from_child[1], STDERR_FILENO) == -1) dup2_error(2);/*check bad dup2() sys call attempting to copy pipe STDERR to from_child[1] */
	     
	     /* child process executes the shell and closes/dups all pipes necessary for InterProcess Communication*/
	     char *execvp_argv[2];
	     char execvp_filename[] = "/bin/bash"; 
	     execvp_argv[0] = execvp_filename; 
	     execvp_argv[1] = NULL;
	     if (execvp(execvp_filename, execvp_argv) == -1) exec_error();  /*check bad execvp() sys call */
	   }
	 else
	   {
	     /*two pollfds structures, one that describes buff(stdin) and one for output of shell (read end of pipe from_child[0]*/
	     struct pollfd poll_child_fds[2];
	     
	     poll_child_fds[0].fd = STDIN_FILENO;/*because child/parent share STDIN but only Parent process takes inputfrom keyboard we only need to watch STDIN */
	     poll_child_fds[0].events = POLLIN | POLLHUP | POLLERR; /*check for changes in status of FD e.g. input (POLLIN) or error(POLLHUP|POLLERR) */

	     poll_child_fds[1].fd = from_child[0];/*we wait for the READ end of pipe to have data after the Shell is done writing to it, so we poll this isntead of the shared STDOUT between child and parent Process */
	     poll_child_fds[1].events = POLLIN | POLLHUP | POLLERR; /*check for changes in status of FD e.g. input (POLLIN) or error(POLLHUP|POLLERR) */
	     
	     /*closing any ends of pipe not necessary for IPC */
	     if (close(to_child[0])== -1) close_error(); /*error closing read end of pipe to child */ 
	     if (close(from_child[1]) == -1) close_error(); /*error closing write end of pipe from child */

	     /* declare buffs for child process and parent process to map the different control characters to their predefined sequences fo correct output (or correct processing) as defined by the spec */  
	     char buff_to_shell[255];
	     int shell_count = 0;

	     int read_Count = 0; 
	     char mod_buff[255];
	     
	     int mod_count = 0;
	     int i; 
	     while (1)
	       {
		 /*now we poll both STDIN and the read end of from_child[0] for pending input with timeout = 0 for strict alternation between the 2 sources of data flow */ 
		 int polled = poll(poll_child_fds, 2, 0); 
		 if (polled < 0) poll_error(); /*check bad poll() sys call */
		 
		 if (poll_child_fds[0].revents & POLLIN) /*user has typed something to STDIN, ready for reading*/
		   {
		     /*store the amount of Bytes read in read_Count */
		     read_Count = read(STDIN_FILENO, buff, sizeof(buff));
		     
		     if (read_Count<0) read_fail(); /* check bad read() sys call */
		     
		     // echoing <cr> or <lf> to <lf><cr> == '\r\n' 
		     int c = ctrl_c(buff, read_Count);
		     int d = ctrl_d(buff, read_Count); 
		     
		     if (d != 0) close(to_child[1]); /*reading ^D closes WRITE end of pipe to child process /bin/bash (e.g. there still may be stuff to process in the pipe not yet passed to shell so finish processing that before we kill child process*/
		     if (c != 0) kill(child, SIGINT); /* reading ^C kills program with SIGINT */	        
		     mod_count = 0; 
		     /* modify our buffer to map \n | \r to \r\n for parent process (terminal display) */
		     for(i = 0; i < read_Count; i++)
		       {
			 if ((buff[i] == '\n') | (buff[i] == '\r'))
			   {
			     mod_buff[mod_count] = '\r';
			     mod_count++; 
			     mod_buff[mod_count] = '\n';
			     mod_count++; 
			   }
			 else
			   {
			     mod_buff[mod_count] = buff[i]; 
			     mod_count++; 
			   }
		       }
		     write(STDOUT_FILENO, mod_buff, mod_count); /*write to STDOUT(shared by parent/child) contents of mod_buff */
		     shell_count = 0;
		     int j;
		     /*modify mod_buff to map \r\n to \n in buff_to_shell for child process (bash) input*/   
		     for (j = 0; j < mod_count; j++)
		       {
			 if ((j != 254) && (mod_buff[j] == '\r' && mod_buff[j+1] == '\n'))
			   {
			     buff_to_shell[shell_count] = '\n';
			     shell_count++; 
			   }
			 else
			   {
			     buff_to_shell[shell_count] = mod_buff[j];
			     shell_count++; 
			   }
		       }
		     write(to_child[1], buff_to_shell, shell_count); /*shell output is written to the WRITE end of pipe that child process cannot write to*/   
		   }
		 
		 /* available input for child process to read e.g. user passed command to child process */
		 if (poll_child_fds[1].revents & POLLIN)
		   {
		     read_Count = read(from_child[0], buff, sizeof(buff)); /*read guaranteed not to fail here, either their is available input from child process or read returns 0 (EOF) meaning the pipe was already closed and we must process rest of data and kill child process*/
		     if (read_Count < 0) read_fail();
		     /*map <cr> -> <cr><lf> as shell output always \n terminated */
		     mod_count = 0;
		     for (i = 0; i < read_Count; i++)
		       {
			 if (buff[i] == '\n')
			   {
			     mod_buff[mod_count] = '\r';
			     mod_count++; 
			     mod_buff[mod_count] = '\n';
			     mod_count++; 
			   }
			 else
			   {
			     mod_buff[mod_count] = buff[i];
			     mod_count++; 
			   }
		       }
		     
		     /*SHUT DOWN PROCESSING */
		     /* we received an EOF from shell, read returns 0, read_Count == 0*/
		     if (read_Count == 0)
		       {
			 pid_t childExit;
			 /*use status to save return value of waitpid() for later WIFEXITED and WIFESIGNALED macros defined for waitpid() */
			 int status, exitStatus;
			 /*using waitpid() and WIFEXITED, WIFSIGNALED to wait for childs change of state(return) after succesful exec of bash command*/
			 childExit = waitpid(child, &status, WUNTRACED | WCONTINUED); /* WUNTRACED | WCONTINUED, returns if a child has stopped but not traced, or if stopped child has been resumed by SIGCONT (0) else returns -1*/
			 
			 if (childExit == -1) wait_error();/*bad call to waitpid(), e.g. child failed to return normally */
			 
			 /*Child terminated normally */
			 if (WIFEXITED(status)) /* WIFEXITED returns true if child terminated normally*/ 
			   {
			     exitStatus = WEXITSTATUS(status); /*gets exitStatus/signal, stores signal in least sig. 7 bytes*/ 
			     fprintf(stderr, "SHELL EXIT SIGNAL=%d STATUS=%d\n\r", exitStatus, exitStatus); 
			     tcsetattr(STDIN_FILENO, TCSANOW, &old); /*restore old terminal attributes before shut down*/
			     exit(0); 
			   }
			 /* child process received terminating signal */ 
			 else if (WIFSIGNALED(status)) /*WIFSIGNALED returns true if child process was terminated by a signal */
			   {
			     fprintf(stderr, "Program exited with signal=%d\n\r", WTERMSIG(status)); /* WTERMSIG(status) to get SIGNAL # that caused child process to be terminated */
			     tcsetattr(STDIN_FILENO, TCSANOW, &old); /*restore old terminal attributes before shut down*/
			     exit(1); 
			   }
			 /* child did not terminate normally and no signals received */
			 fprintf(stderr, "No signals received and no Return Code to be extracted after execution of shell. Exiting Failure.");
			 tcsetattr(STDIN_FILENO, TCSANOW, &old); /*restore old terminal attributes before shut down*/
			 exit(1); 
		       }
		     
		     /*after all shut down processing for child process write output from child process (stored in mod_buff) to display (stdout shared by parent and process)*/
		     write(STDOUT_FILENO, mod_buff, mod_count); 
		   }
		 
		 /*we must process all remaining STDIN to_child and print to display because socket was closed (e.g. user entered ^D)*/
		 if((poll_child_fds[1].revents & POLLHUP) || (poll_child_fds[1].revents & POLLERR))
		   {
		     /* checking remaining output from_child even after we have encountered RC or exit signal */
		     read_Count = read(from_child[0], buff, sizeof(buff)); /* read here again guaranteed not to fail readcount >= 0 always*/
		     if (read_Count < 0) read_fail(); 
		     mod_count = 0; 
		    
		     /*map \n of child process- e.g. bin/bash, whose output is awlays \n (newline) terminated  to \r\n */ 
		     for (i = 0; i < read_Count; i++)
		       {
			 if (buff[i] == '\n')
			   {
			     mod_buff[mod_count] = '\r';
			     mod_count++; 
			     mod_buff[mod_count] = '\n';
			     mod_count++;
			   }
			 else
			   {
			     mod_buff[mod_count] = buff[i];
			     mod_count++; 
			   }
		       }
		     write(STDOUT_FILENO, mod_buff, mod_count); /*write to stdout(shared) output of shell with correct mapping of \n to <cr><lf> */
		     
		     /* one more time we wait for child to terminate when there is nothing to read in to_child[0] and it has already been closed */
		     
		     pid_t childExit;
		     int status, exitStatus;
		     childExit = waitpid(child, &status, WUNTRACED | WCONTINUED) ;/* using waitpid again to process child return */
		     if (childExit == -1) wait_error(); /*bad call to waitpid(), e.g. child failed to return normally */
		       
		     /*child terminated normally */
		     if (WIFEXITED(status))
		       {
			 exitStatus = WEXITSTATUS(status);
			 fprintf(stderr, "SHELL EXIT SIGNAL=%d STATUS=%d\n\r", exitStatus, exitStatus); 
			 tcsetattr(STDIN_FILENO, TCSANOW, &old);
			 exit(0); 
		       }
		     /*child process received terminating signal */ 
		     else if (WIFSIGNALED(status))
		       {
			 fprintf(stderr, "Program exited with signal, %d \n\r", WTERMSIG(status));
			 tcsetattr(STDIN_FILENO, TCSANOW, &old);
			 exit(1); 
		       }
		     /* child did not terminate normally and no signals received */
		     fprintf(stderr, "No signals received and no Return Code to be extracted after execution of shell. Exiting Failure. \n\r");
		     tcsetattr(STDIN_FILENO, TCSANOW, &old); 
		     exit(1); 
		   }
	       }
	   }
       }
     else
       {
	 /*code when no shell flag is specified */
	 /* E.G. noncanonical INPUT mode with NO ECHO! just write this to stdout() as long as the user keeps inputting stuff to STDIN */
	 /*Doing an initial read of sizeof(buff) */
	 int read_Count = read(STDIN_FILENO, buff, sizeof(buff));
	 if (read_Count < 0) read_fail(); /*check bad read() sys call */
	 
	 /*SHUT DOWN PROCESSING */
	 /*parent process terminates when ^D is entered */
	 if (ctrl_d(buff, read_Count))
	   {
	     tcsetattr(STDIN_FILENO, TCSANOW, &old); /*restore old terminal settings before exit*/
	     fprintf(stderr, "^D entered. Program exited immediately.\n");
	     exit(0); 
	   }
	 char mod_buff[255];
	 int mod_count = 0;
	 int i = 0;
	 /*mapping \n or \r to \r\n just as a normal terminal does (this is basically an excercise, we only really care for \r\n differentiation when we pass output from terminal to shell (\r|\n -> \n) as bash commands are newline terminated and (\n -> \r\n) for parent process output - (terminal) as output of bash commands is also new line terminated */ 
	 for (i=0; i < read_Count; i++)
	   {
	     if((buff[i] == '\n') | (buff[i] == '\r'))
	       {
		 mod_buff[mod_count] = '\r';
		 mod_count++;
		 mod_buff[mod_count] = '\n';
		 mod_count++;
	       }
	     else
	       {
		 mod_buff[mod_count] = buff[i];
		 mod_count++; 
	       }
	   }
	 while(read_Count != 0)
	   {
	     if (write(STDOUT_FILENO, mod_buff, mod_count) < 0) write_error();
	     /*write everything read to STDOUT_FILENO and keep doing reads until read_Count is 0. (basically do not stop if there is still input to be read in STDIN) */
	     read_Count = read(STDIN_FILENO, buff, sizeof(buff)); /* read guaranteed not to fail here (while loop condition) */
	     if (read_Count < 0) read_fail(); 
	     /*SHUT DOWN PROCESSING */
	     /*parent process terminates when ^D is entered */
	     if (ctrl_d(buff, read_Count))
	       {
		 tcsetattr(STDIN_FILENO, TCSANOW, &old);
		 fprintf(stderr, "^D entered. Program exited immediately.\n");
		 exit(0); 		   
	       }

	     mod_count = 0;
/*mapping \n or \r to \r\n just as a normal terminal does (this is basically an excercise, we only really care for \r\n differentiation when we pass output from terminal to shell (\r|\n -> \n) as bash commands are newline terminated and (\n -> \r\n) for parent process output - (terminal) as output of bash commands is also new line terminated */ 
	     for (i = 0; i < read_Count; i++)
	       {
		 if((buff[i] == '\n') | (buff[i] == '\r'))
		   {
		     mod_buff[mod_count] = '\r';
		     mod_count++;
		     mod_buff[mod_count] = '\n';
		     mod_count++; 
		   }
		 else
		   {
		     mod_buff[mod_count] = buff[i];
		     mod_count++; 
		   }
	       }
	   }
	 tcsetattr(STDIN_FILENO, TCSANOW, &old); /*user has stopped inputting stuff to STDIN so reset terminal attributes and exit*/
	 exit(0); 
       }
}
	       
	         
	    
